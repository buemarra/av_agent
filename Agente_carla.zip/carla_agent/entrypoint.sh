#!/bin/bash
source /home/robesafe/workspace/.env
exec bash
